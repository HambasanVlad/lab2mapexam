package model.adt;

public interface MyIList<T> {
    void add(T v);
    String toString();
}
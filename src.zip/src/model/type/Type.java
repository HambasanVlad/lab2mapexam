package model.type;

import model.value.Value; // ADAUGAT

public interface Type {
    Value defaultValue(); // ADAUGAT
}